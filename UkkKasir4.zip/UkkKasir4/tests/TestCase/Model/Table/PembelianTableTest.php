<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\PembelianTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\PembelianTable Test Case
 */
class PembelianTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\PembelianTable
     */
    protected $Pembelian;

    /**
     * Fixtures
     *
     * @var array<string>
     */
    protected array $fixtures = [
        'app.Pembelian',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('Pembelian') ? [] : ['className' => PembelianTable::class];
        $this->Pembelian = $this->getTableLocator()->get('Pembelian', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->Pembelian);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @link \App\Model\Table\PembelianTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
