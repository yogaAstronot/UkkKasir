<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * PembelianFixture
 */
class PembelianFixture extends TestFixture
{
    /**
     * Table name
     *
     * @var string
     */
    public string $table = 'pembelian';
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'id_penjualan' => 1,
                'harga' => 1.5,
                'kembalian' => 1.5,
                'date' => '2026-11-11',
            ],
        ];
        parent::init();
    }
}
