<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<header>
    <div class="top-nav-links margin-left: 10px;">
        <a href="<?= $this->Url->build('/users/add') ?>">register</a>
        <a href="<?= $this->Url->build('') ?>">login</a>
    </div>
</header>

<div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 50vh; background-color: brown; border-radius: 30px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); margin-top: 20px;">
    <button>
        <a href="<?= $this->Url->build('/penjualan/add') ?>" style="text-decoration: none; color: white;">penjualan</a>
    </button>

    <button>
        <a href="<?= $this->Url->build('/pelanggan/add') ?>" style="text-decoration: none; color: white;">pelanggan</a>
    </button>

    <button>
        <a href="<?= $this->Url->build('/produk') ?>" style="text-decoration: none; color: white;">produk</a>
    </button>
</div>




</html>