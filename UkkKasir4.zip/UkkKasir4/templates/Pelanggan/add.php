<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Pelanggan $pelangganEntity
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Pelanggan'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="pelanggan form content">
            <?= $this->Form->create($pelangganEntity) ?>
            <fieldset>
                <legend><?= __('Add Pelanggan') ?></legend>
                <?php
                    echo $this->Form->control('NamaPelanggan');
                    echo $this->Form->control('Alamat');
                    echo $this->Form->control('NomorTelepon');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
