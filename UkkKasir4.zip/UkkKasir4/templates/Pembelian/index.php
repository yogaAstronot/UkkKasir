<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Pembelian> $pembelian
 */
?>
<div class="pembelian index content">
    <?= $this->Html->link(__('New Pembelian'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Pembelian') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('id_penjualan') ?></th>
                    <th><?= $this->Paginator->sort('harga') ?></th>
                    <th><?= $this->Paginator->sort('kembalian') ?></th>
                    <th><?= $this->Paginator->sort('date') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pembelian as $pembelianEntity): ?>
                <tr>
                    <td><?= $this->Number->format($pembelianEntity->id) ?></td>
                    <td><?= $this->Number->format($pembelianEntity->id_penjualan) ?></td>
                    <td><?= $this->Number->format($pembelianEntity->harga) ?></td>
                    <td><?= $this->Number->format($pembelianEntity->kembalian) ?></td>
                    <td><?= h($pembelianEntity->date) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $pembelianEntity->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $pembelianEntity->id]) ?>
                        <?= $this->Form->postLink(
                            __('Delete'),
                            ['action' => 'delete', $pembelianEntity->id],
                            [
                                'method' => 'delete',
                                'confirm' => __('Are you sure you want to delete # {0}?', $pembelianEntity->id),
                            ]
                        ) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>