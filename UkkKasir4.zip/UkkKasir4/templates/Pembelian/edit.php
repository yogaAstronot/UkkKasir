<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Pembelian $pembelianEntity
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $pembelianEntity->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $pembelianEntity->id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Pembelian'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="pembelian form content">
            <?= $this->Form->create($pembelianEntity) ?>
            <fieldset>
                <legend><?= __('Edit Pembelian') ?></legend>
                <?php
                    echo $this->Form->control('id_penjualan');
                    echo $this->Form->control('harga');
                    echo $this->Form->control('kembalian');
                    echo $this->Form->control('date');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
