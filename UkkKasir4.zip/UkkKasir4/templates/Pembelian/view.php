<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Pembelian $pembelianEntity
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Pembelian'), ['action' => 'edit', $pembelianEntity->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Pembelian'), ['action' => 'delete', $pembelianEntity->id], ['confirm' => __('Are you sure you want to delete # {0}?', $pembelianEntity->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Pembelian'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Pembelian'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="pembelian view content">
            <h3><?= h($pembelianEntity->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($pembelianEntity->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Penjualan') ?></th>
                    <td><?= $this->Number->format($pembelianEntity->id_penjualan) ?></td>
                </tr>
                <tr>
                    <th><?= __('Harga') ?></th>
                    <td><?= $this->Number->format($pembelianEntity->harga) ?></td>
                </tr>
                <tr>
                    <th><?= __('Kembalian') ?></th>
                    <td><?= $this->Number->format($pembelianEntity->kembalian) ?></td>
                </tr>
                <tr>
                    <th><?= __('Date') ?></th>
                    <td><?= h($pembelianEntity->date) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>