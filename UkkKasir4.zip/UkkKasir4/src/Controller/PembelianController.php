<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Pembelian Controller
 *
 * @property \App\Model\Table\PembelianTable $Pembelian
 */
class PembelianController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->Pembelian->find();
        $pembelian = $this->paginate($query);

        $this->set(compact('pembelian'));
    }

    /**
     * View method
     *
     * @param string|null $id Pembelian id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $pembelianEntity = $this->Pembelian->get($id, contain: []);
        $this->set(compact('pembelianEntity'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $pembelianEntity = $this->Pembelian->newEmptyEntity();
        if ($this->request->is('post')) {
            $pembelianEntity = $this->Pembelian->patchEntity($pembelianEntity, $this->request->getData());
            if ($this->Pembelian->save($pembelianEntity)) {
                $this->Flash->success(__('The pembelian has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The pembelian could not be saved. Please, try again.'));
        }
        $this->set(compact('pembelianEntity'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Pembelian id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $pembelianEntity = $this->Pembelian->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $pembelianEntity = $this->Pembelian->patchEntity($pembelianEntity, $this->request->getData());
            if ($this->Pembelian->save($pembelianEntity)) {
                $this->Flash->success(__('The pembelian has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The pembelian could not be saved. Please, try again.'));
        }
        $this->set(compact('pembelianEntity'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Pembelian id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $pembelianEntity = $this->Pembelian->get($id);
        if ($this->Pembelian->delete($pembelianEntity)) {
            $this->Flash->success(__('The pembelian has been deleted.'));
        } else {
            $this->Flash->error(__('The pembelian could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
