<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Pembelian Model
 *
 * @method \App\Model\Entity\Pembelian newEmptyEntity()
 * @method \App\Model\Entity\Pembelian newEntity(array $data, array $options = [])
 * @method array<\App\Model\Entity\Pembelian> newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Pembelian get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \App\Model\Entity\Pembelian findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \App\Model\Entity\Pembelian patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\App\Model\Entity\Pembelian> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\Pembelian|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \App\Model\Entity\Pembelian saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\App\Model\Entity\Pembelian>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Pembelian>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\Pembelian>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Pembelian> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\Pembelian>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Pembelian>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\Pembelian>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Pembelian> deleteManyOrFail(iterable $entities, array $options = [])
 */
class PembelianTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('pembelian');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('id_penjualan')
            ->requirePresence('id_penjualan', 'create')
            ->notEmptyString('id_penjualan');

        $validator
            ->decimal('harga')
            ->requirePresence('harga', 'create')
            ->notEmptyString('harga');

        $validator
            ->decimal('kembalian')
            ->requirePresence('kembalian', 'create')
            ->notEmptyString('kembalian');

        $validator
            ->date('date')
            ->requirePresence('date', 'create')
            ->notEmptyDate('date');

        return $validator;
    }
}
