<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Produk Entity
 *
 * @property int $ProdukID
 * @property int $id_kategori
 * @property string $NamaProduk
 * @property string $Harga
 * @property int $Stok
 */
class Produk extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'id_kategori' => true,
        'NamaProduk' => true,
        'Harga' => true,
        'Stok' => true,
    ];
}
