<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Pembelian Entity
 *
 * @property int $id
 * @property int $id_penjualan
 * @property string $harga
 * @property string $kembalian
 * @property \Cake\I18n\Date $date
 */
class Pembelian extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'id_penjualan' => true,
        'harga' => true,
        'kembalian' => true,
        'date' => true,
    ];
}
